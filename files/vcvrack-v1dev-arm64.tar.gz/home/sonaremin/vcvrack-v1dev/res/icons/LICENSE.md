All icons are licensed under CC BY 3.0.
https://creativecommons.org/licenses/by/3.0/
https://thenounproject.com/

Paper by Madeleine Bennett from the Noun Project
Folder by Icon Solid from the Noun Project
Save by Landan Lloyd from the Noun Project
Cat by Nabilauzwa from the Noun Project
Stopwatch by Arthur Shlain from the Noun Project
Sound by Gregor Cresnar from the Noun Project
Refresh by un·delivered from the Noun Project
Lock by Andres Gleixner from the Noun Project
